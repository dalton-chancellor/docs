# -*- coding: utf-8 -*-
"""
Created on Wed Jan 27 11:14:04 2021

@author: dchancellor2022
"""
evpy is a pyhton library used to predict efficiency in electric power trains given high level component specifications. It can be used to predict motor performance, a motors torque/speed/efficeiency contour, motor size given aspect ratio and torque, losses in an ESC given motor performance, ESC size, a battery’s voltage given time under a load, and battery mass given duration and specific energy.